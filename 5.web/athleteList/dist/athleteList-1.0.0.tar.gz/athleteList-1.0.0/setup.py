from distutils.core import setup
setup(
        name = 'athleteList',
        version = '1.0.0',
        py_modules = ['athleteList'],
        author = 'James',
        author_email = '958212290@qq.com',
        url = 'null',
        description = 'a class of athlete data', 
    )
