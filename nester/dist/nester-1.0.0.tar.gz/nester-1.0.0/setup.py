from distutils.core import setup

setup(
        name = 'nester',
        version = '1.0.0',
        py_modules = ['nester'],
        author = 'JackYan',
        author_email = '958212290@qq.com',
		url = 'http://www.jackyan.com',
		description = 'A simple printer of nested lists',
    )
